#@AUTHOR: Vamsi Krishna Kodimela


relation=input("Enter atrributes of Relation(ex: abcdef)::")
#importing file to generate closureset of attribute
from closureset import *
necessary=relation
mixed=""

for i in FD:
        for j in i[1]:
                if j in necessary:
                        necessary=necessary.replace(j,'')
for i in FD:
        for j in i[0]:
                if (j not in mixed)and (j not in necessary):
                        mixed+=j

def candidate_key(base,left):
        out=closure_generator(FD,base)
        flag=1
        for i in relation:
                if i not in out:
                        flag=0
                        break
        if flag !=0:
                print (base,"+")
                return
        else:
                for i in left:
                        flag=1
                        out=closure_generator(FD,i+base)
                        for j in relation:
                                if j not in out:
                                        flag=0
                                        break
                        if flag==1:
                                print(i+base)
                                left=left.replace(i,'')     
                x=len(left)
                for i in range(x):
                        candidate_key(left[0]+base,left.replace(left[0],''))
                        left=left.replace(left[0],'')

print("Candidate keys for the Given relation are::")                        
candidate_key(necessary,mixed)
