#@AUTHOR: Vamsi Krishna Kodimela

n=int(input("Enter Number of FDs::"))
FD=[]
for i in range(n):
        FD.append([])
        FD[i].append(input("Enter Left Hand side value seperated by , ::"))
        FD[i].append(input("Enter Right Hand side value seperated by , ::"))
def closure_generator(FD,n):
    closure=""
    closure+=n
    for z in range(len(FD)+1):
            for i in FD:
                    check=1
                    for k in i[0]:
                            if k not in closure:
                                    check=0
                    if check==1:
                            for j in i[1]:
                                    if j not in closure:
                                            closure+=j
    return closure

